insert into Tipo_de_Sensor(IDTS, Ar, Solo, �gua)
values(00, 'N�o', 'Sim', 'N�o')

insert into Tipo_de_Sensor(IDTS, Ar, Solo, �gua)
values(11, 'N�o', 'Sim', 'N�o')

insert into Tipo_de_Sensor(IDTS, Ar, Solo, �gua)
values(22, 'N�o', 'Sim', 'N�o')

insert into Tipo_de_Sensor(IDTS, Ar, Solo, �gua)
values(33, 'N�o', 'Sim', 'N�o')

insert into Tipo_de_Sensor(IDTS, Ar, Solo, �gua)
values(44, 'N�o', 'Sim', 'N�o')

insert into Tipo_de_Sensor(IDTS, Ar, Solo, �gua)
values(55, 'N�o', 'Sim', 'N�o')

insert into Tipo_de_Sensor(IDTS, Ar, Solo, �gua)
values(66, 'N�o', 'Sim', 'N�o')

insert into Tipo_de_Sensor(IDTS, Ar, Solo, �gua)
values(77, 'N�o', 'Sim', 'N�o')

insert into Tipo_de_Sensor(IDTS, Ar, Solo, �gua)
values(88, 'N�o', 'Sim', 'N�o')

insert into Tipo_de_Sensor(IDTS, Ar, Solo, �gua)
values(99, 'N�o', 'Sim', 'N�o')

insert into Tipo_de_Sensor(IDTS, Ar, Solo, �gua)
values(1010, 'N�o', 'N�o', 'Sim')

insert into Tipo_de_Sensor(IDTS, Ar, Solo, �gua)
values(1111, 'N�o', 'Sim', 'N�o')

insert into Tipo_de_Sensor(IDTS, Ar, Solo, �gua)
values(1212, 'N�o', 'Sim', 'N�o')

insert into Tipo_de_Sensor(IDTS, Ar, Solo, �gua)
values(1313, 'N�o', 'Sim', 'N�o')

insert into Tipo_de_Sensor(IDTS, Ar, Solo, �gua)
values(1414, 'N�o', 'Sim', 'N�o')

insert into Tipo_de_Sensor(IDTS, Ar, Solo, �gua)
values(1515, 'N�o', 'Sim', 'N�o')

insert into Tipo_de_Sensor(IDTS, Ar, Solo, �gua)
values(1616, 'N�o', 'Sim', 'N�o')

insert into Tipo_de_Sensor(IDTS, Ar, Solo, �gua)
values(1717, 'N�o', 'Sim', 'N�o')

insert into Tipo_de_Sensor(IDTS, Ar, Solo, �gua)
values(1818, 'N�o', 'Sim', 'N�o')

insert into Tipo_de_Sensor(IDTS, Ar, Solo, �gua)
values(2020, 'N�o', 'Sim', 'N�o')

insert into Tipo_de_Sensor(IDTS, Ar, Solo, �gua)
values(2121, 'N�o', 'Sim', 'N�o')

insert into Tipo_de_Sensor(IDTS, Ar, Solo, �gua)
values(2222, 'N�o', 'Sim', 'N�o')

insert into Tipo_de_Sensor(IDTS, Ar, Solo, �gua)
values(2323, 'N�o', 'Sim', 'N�o')

insert into Tipo_de_Sensor(IDTS, Ar, Solo, �gua)
values(2424, 'N�o', 'Sim', 'N�o')