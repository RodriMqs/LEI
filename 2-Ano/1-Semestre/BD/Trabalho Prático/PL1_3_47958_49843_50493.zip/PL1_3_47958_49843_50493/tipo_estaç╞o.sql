insert into Tipo_de_Esta��o(IDTE, M�vel, Permanente, ID)
values(0000, 'N�o', 'Sim', 1)

insert into Tipo_de_Esta��o(IDTE, M�vel, Permanente, ID)
values(0001, 'N�o', 'Sim', 2)

insert into Tipo_de_Esta��o(IDTE, M�vel, Permanente, ID)
values(0011, 'N�o', 'Sim', 3)

insert into Tipo_de_Esta��o(IDTE, M�vel, Permanente, ID)
values(0100, 'N�o', 'Sim', 4)

insert into Tipo_de_Esta��o(IDTE, M�vel, Permanente, ID)
values(0101, 'N�o', 'Sim', 5)

insert into Tipo_de_Esta��o(IDTE, M�vel, Permanente, ID)
values(0110, 'N�o', 'Sim', 6)

insert into Tipo_de_Esta��o(IDTE, M�vel, Permanente, ID)
values(1111, 'N�o', 'Sim', 7)

insert into Tipo_de_Esta��o(IDTE, M�vel, Permanente, ID)
values(1000, 'N�o', 'Sim', 8)

insert into Tipo_de_Esta��o(IDTE, M�vel, Permanente, ID)
values(1001, 'N�o', 'Sim', 9)

insert into Tipo_de_Esta��o(IDTE, M�vel, Permanente, ID)
values(1010, 'N�o', 'Sim', 10)

insert into Tipo_de_Esta��o(IDTE, M�vel, Permanente, ID)
values(1011, 'Sim', 'N�o', 11)

insert into Tipo_de_Esta��o(IDTE, M�vel, Permanente, ID)
values(1100, 'N�o', 'Sim', 12)

insert into Tipo_de_Esta��o(IDTE, M�vel, Permanente, ID)
values(1101, 'N�o', 'Sim', 13)

insert into Tipo_de_Esta��o(IDTE, M�vel, Permanente, ID)
values(1110, 'N�o', 'Sim', 14)

insert into Tipo_de_Esta��o(IDTE, M�vel, Permanente, ID)
values(1111, 'N�o', 'Sim', 15)

insert into Tipo_de_Esta��o(IDTE, M�vel, Permanente, ID)
values(10000, 'N�o', 'Sim', 16)

insert into Tipo_de_Esta��o(IDTE, M�vel, Permanente, ID)
values(10001, 'N�o', 'Sim', 17)

insert into Tipo_de_Esta��o(IDTE, M�vel, Permanente, ID)
values(10010, 'N�o', 'Sim', 18)

insert into Tipo_de_Esta��o(IDTE, M�vel, Permanente, ID)
values(10011, 'N�o', 'Sim', 19)

insert into Tipo_de_Esta��o(IDTE, M�vel, Permanente, ID)
values( 10100, 'N�o', 'Sim', 20)

insert into Tipo_de_Esta��o(IDTE, M�vel, Permanente, ID)
values(10101, 'N�o', 'Sim', 21)

insert into Tipo_de_Esta��o(IDTE, M�vel, Permanente, ID)
values(10110, 'N�o', 'Sim', 22)

insert into Tipo_de_Esta��o(IDTE, M�vel, Permanente, ID)
values(10111, 'N�o', 'Sim', 23)

insert into Tipo_de_Esta��o(IDTE, M�vel, Permanente, ID)
values(11000, 'N�o', 'Sim', 24)

